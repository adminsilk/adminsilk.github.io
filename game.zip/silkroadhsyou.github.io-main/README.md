1. NewCodespace열기
2. dist, parcel-cache, node_modules 지우기
3. yarn
4. yarn build
5. git add -A
6. git commit -m "122222"
7. git push origin main

# Marble roulette

This is a lucky draw by dropping marbles.

[Demo]( https://lazygyu.github.io/roulette )

# Requirements

- Typescript
- Parcel
- box2d-wasm

# Development

```shell
> yarn
> yarn dev
```

# Build

```shell
> yarn build
```

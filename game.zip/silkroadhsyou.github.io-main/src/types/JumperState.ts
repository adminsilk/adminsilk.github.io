export interface JumperState {
    x: number,
    y: number,
    radius: number,
    isTemporary: boolean,
}

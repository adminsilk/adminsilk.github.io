export interface VectorLike {
    x: number;
    y: number;
}

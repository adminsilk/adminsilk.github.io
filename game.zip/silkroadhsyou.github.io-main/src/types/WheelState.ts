export interface WheelState {x: number, y: number, size: number, angle: number}

export type Rect = {
    x: number;
    y: number;
    w: number;
    h: number;
};
